


public class ProducerConsumer {

    public static void main(String[] args) {
        
        GUIFrame frame = new GUIFrame();
        frame.show();
    }
    
}
